%% finish_maabada_Part2
% Oriel kowler 312496045
% Eliyahou garti 302169354

% rotate 
% Rotation of the image according to the obtained deviation angle
function rotate_func = rotate(pic, alpha) 
% rotates pic by alpha degrees in a counterclockwise direction around its center point.
% 'crop' - Make output image the same size as the input image, cropping the rotated image to fit.
% 'bilinear' - Bilinear interpolation. The output pixel value is a weighted average of pixels
% in the nearest 2-by-2 neighborhood.
rotate_func = imrotate(pic,-alpha,'bilinear','crop');
end