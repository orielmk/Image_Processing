%% finish_maabada_Part2
% Oriel kowler 312496045
% Eliyahou garti 302169354

% load picture 
% Receives an image file from the user and returns an image in a suitable format
function up_load_func = up_load(user)
% massage 1 to the user, append - Connects the parts of the message
msg1 = append('Hello ',user,', Please upload an image car from the ''pic2'' folder in the following formats: jpg, tif, png');
disp(msg1);                                  % Display value of variable
% returns the file name and path to the file 
[name, path] = uigetfile ( {'*.jpg';'*.tif';'*.png'} ,string);  % returns the file name and path to the file
up_load_func = imread(fullfile(path, name)); % Build full file name from parts - path to the file and the name
                                             % and read that to pic
% massage 2 to the user
msg2 = append('Thank you ',user,', Please wait patiently for the requested license plate to load');
disp(msg2);
end