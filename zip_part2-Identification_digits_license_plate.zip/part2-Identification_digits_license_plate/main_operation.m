%% finish_maabada_Part2
% Oriel kowler 312496045
% Eliyahou garti 302169354

% main_plate 
% operate all the functions

% For start please select ctrl+enter
% start - ask for the user name
prompt = "Hello, your name please:\n";
user = input(prompt, "s");  % Request user input
                            % returns the entered text, without evaluating the input as an expression.

% load image user
pic = up_load(user);

% return The license plate and the angle of deviation
[plate, alpha] = plate_and_alpha(pic);

% Checking whether it is necessary to correct the rotation of the image 
% and while the angle of deviation > 0.6 continue to correct

while abs(alpha)>0.6
    pic_rotate = rotate(pic, alpha);                   % The image after the rotation correction
    [plate, alpha] = plate_and_alpha(pic_rotate);     % return The license plate and the angle of                                                   % deviation after fixed
end

% Pick up the license plate and get the serial number
serial = serial_number(plate);

% plot the results
% subplot(m,n,p) = divides the current figure into an m-by-n grid and creates axes
% in the position specified by p. 
subplot(1,2,1); imshow(pic); title("The Original picture");  
subplot(1,2,2); imshow(plate); title("Hello "+user+" your serial number is: "+serial+" ");