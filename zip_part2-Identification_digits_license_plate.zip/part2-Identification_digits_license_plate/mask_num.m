%% finish_maabada_Part2
% Oriel kowler 312496045
% Eliyahou garti 302169354

% mask_num 
% saperate the number at the plate and return it in white color
function mask_num_func = mask_num(pic)
pic_gray = rgb2gray(pic);               % convert RGB to gray
pic_bin = imbinarize(pic_gray, 0.27);   % creates a binary image from pic_gray using the threshold o.27
bw = ~pic_bin;                          % convert black and white
% Noise removal in relation to the number of pixels in the image
[R C] = size(pic);                      % size of the pic
clean = round(R*C*0.00003);             % calculate the clean resulation for one number
mask_num_func = bwareaopen(bw, clean);  % clean the image from small noise then number
end

