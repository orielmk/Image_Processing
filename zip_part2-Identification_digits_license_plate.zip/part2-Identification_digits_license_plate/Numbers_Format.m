%% finish_maabada_Part2-Numbers_Format
% Oriel kowler 312496045
% Eliyahou garti 302169354

% Numbers Formats
% This is used to call the saved images of digits and then save them
% as a new template in MATLAB memory

%Natural Numbers
one1   = imread('numbers/11.bmp'); 
one2   = imread('numbers/12.bmp'); 
two1   = imread('numbers/21.bmp');
two2   = imread('numbers/22.bmp');
three  = imread('numbers/3.bmp'); 
four1  = imread('numbers/41.bmp');
four2  = imread('numbers/42.bmp');
five1  = imread('numbers/51.bmp');
five2  = imread('numbers/52.bmp'); 
six1   = imread('numbers/61.bmp');
six2   = imread('numbers/62.bmp');
six3   = imread('numbers/63.bmp');
seven  = imread('numbers/7.bmp'); 
eight1 = imread('numbers/81.bmp');
eight2 = imread('numbers/82.bmp');
eight3 = imread('numbers/83.bmp');
nine1  = imread('numbers/91.bmp');
nine2  = imread('numbers/92.bmp'); 
nine3  = imread('numbers/93.bmp'); 
zero   = imread('numbers/0.bmp');

%Creating Array for Numbers
number = [one1 one2 two1 two2 three four1 four2 five1 five2 six1 six2 six3 seven eight1 eight2 eight3 nine1 nine2 nine3 zero];

% saves only the variables or fields of a structure array specified by variables
save('NewFormats','number') 
clear all
