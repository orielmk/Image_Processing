%% finish_maabada_Part2
% Oriel kowler 312496045
% Eliyahou garti 302169354

% user interface
% For start please select ctrl+enter
main_operation;