%% finish_maabada_Part2
% Oriel kowler 312496045
% Eliyahou garti 302169354

% serial_number 
% Pick up the license plate and get the serial number

function serial_number_func = serial_number(plate)

pic_gray = rgb2gray(plate);   % convert to gray
pic_i = 255 - pic_gray;       % Convert gray values

% Finding the ideal gray value threshold for switching to binary using a histogram
hist_p = imhist(pic_i);       % histogram of image data
cum_p = cumsum(hist_p);       % cumulative sum
[H W] = size(pic_i);          % [Height Width] of the picture
f = (W*H)*(0.7);              % Finding the amount of two-thirds of the pixels in the image
index_f = find(cum_p>f);      % Finding the indexes in the cumulative histogram where there 
                              % are more than two-thirds of the pixels in the image
index_h = hist_p(index_f);    % Finding the indices of the values ​​in the histogram where there
                              % are more than two thirds of the pixels in the image
TF = islocalmin(index_h);     % Finding the index of local minimum values
index_TF = find(TF==1,1);     % Finding the first index local minimum value in TF
index_TF = index_TF + index_f(1);  % add the first index local minimum to the first index of index_f
pic_t = pic_i>index_TF;       % Transferring the image to binary according to the relative threshold 
                              % value we found
                              
pic_t = ~pic_t;               % Convert black-white values

% White noise cleaning in the numbers on the license plate
clean = round(H*W*0.0015);                % calculate the clean resulation for one number
clean_pic1 = bwareaopen(pic_t, clean);    % clean the image from small noise then number
bw = ~clean_pic1;                         % convert black and white

% Noise black removal in relation to the number of pixels in the image from
% the license plate
clean = round(H*W*0.002);                 % calculate the clean resulation for one number
clean_pic2 = bwareaopen(bw, clean);       % clean the image from small noise then number

% Separating the numbers on the license plate for different Azurips by regionprops();  
Iprops = regionprops(clean_pic2,'BoundingBox','Area', 'Image'); % Explained in detail in file
                                                                % 'plate_and_rotate.m' at line 21
count = numel(Iprops);                               % returns the number of elements in array Iprops.
Serial_Num=[];                                       % Initializing the variable of number plate string.

for i=1:count
   w_elem = length(Iprops(i).Image(1,:));            % width of element i in Iprops
   h_elem = length(Iprops(i).Image(:,1));            % height of element i in Iprops
   area_ref = (Iprops(i).Area)/(W*H);                % the reference area of the num to the plate
   num_ref = h_elem/w_elem;                          % the reference area of the num to the plate
   % Checks whether the element is a number on a license plate or something else
   if (H/h_elem)<2.3 & (num_ref>=1) & (num_ref<=4) & 0.01<area_ref & area_ref<0.05
       num_detect = Num_Detection(Iprops(i).Image);  % Sends the number to the function Num_Detection
                                                     % and receives the desired digit
       Serial_Num = [Serial_Num num_detect];         % Appending every digit to the Serial_Num array.
   end
end
serial_number_func = Serial_Num;
end
