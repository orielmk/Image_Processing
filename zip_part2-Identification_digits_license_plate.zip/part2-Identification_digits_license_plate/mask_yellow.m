%% finish_maabada_Part2
% Oriel kowler 312496045
% Eliyahou garti 302169354

% yellow_detect 
% detect the yellow color in the picture
function mask_yel_func = mask_yellow(pic)
% HSV
HSV = rgb2hsv(pic);                % convert RGB to HSV
% saperate layers
hue = HSV(:,:,1);                  % hue layer
sat = HSV(:,:,2);                  % saturation layer
val = HSV(:,:,3);                  % value layer
% create mask
mask_h = (hue>0.01);               % hue threshold
mask_s = (sat>0.3);                % saturation threshold
mask_v = (val>0.4);                % value threshold
mask_yel = mask_h & mask_s & mask_v;            % create the yellow nask 
% Noise removal in relation to the number of pixels in the image
[R C] = size(pic);                              % size of the pic
clean = round(R*C*0.0008);                      % calculate the clean resulation
                                                % Round to nearest decimal or integer
mask_yel_func = bwareaopen(mask_yel, clean);    % Remove small objects from binary image, small then clean
end





