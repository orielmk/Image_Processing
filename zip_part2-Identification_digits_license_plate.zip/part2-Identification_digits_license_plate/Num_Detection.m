%% finish_maabada_Part2-Num_Detection
% Oriel kowler 312496045
% Eliyahou garti 302169354

% Num Detection 
% Reads the Nums from the input image and find the highest matched 
% corresponding digit.

function Num = Num_Detection(section)
 
% load the saved templates
load NewFormats
% resized the input image so it can be compared with the template’s images
section = imresize(section,[42 24]); 
% A matrix ‘rec’ create to record the value of correlation for each alphanumeric template 
% with the characters template from the input image.  
rec = [ ];
% loop to correlates the input image with every image in the template to get the best match.
for n = 1:24:length(number)
    cor = corr2(number(:,n:(n+23)), section); % returns the 2-D correlation coefficient R between sections 
    rec = [rec cor];                         % Appending every correlation coefficient to the array.
end
rec = [rec 0.2];                              % Appending 0.2 correlation coefficient to the array
                                              % to determine a minimum threshold for correlation.
% ‘find()’ command is used to find the index which corresponds to the highest matched digit. 
% Then according to that index, corresponding character is printed using‘if-else’ statement.
index = find(rec==max(rec),1);                % find the first index of the best correlation.

% Finding the appropriate digit according to the index we received.
% Digit '1' corresponds to indexes 1,2
if index==1
    Num='1';
elseif index==2
    Num='1';
% Digit '2' corresponds to indexes 3,4
elseif index==3
    Num='2';
elseif index==4
    Num='2';
% Digit '3' corresponds to index 5
elseif index==5
    Num='3';
% Digit '4' corresponds to indexes 6,7
elseif index==6
    Num='4';
elseif index==7
    Num='4';
% Digit '5' corresponds to indexes 8,9
elseif index==8
    Num='5';
elseif index==9 
    Num='5';
% Digit '6' corresponds to indexes 10,11,12
elseif index==10
    Num='6';
elseif index==11
    Num='6';
elseif index==12
    Num='6';
% Digit '7' corresponds to index 13
elseif index==13
    Num='7';
% Digit '8' corresponds to indexes 14,15,16
elseif index==14
    Num='8';
elseif index==15
    Num='8';
elseif index==16
    Num='8';
% Digit '9' corresponds to indexes 17,18,19
elseif index==17
    Num='9';
elseif index==18
    Num='9';
elseif index==19
    Num='9';
% Digit '0' corresponds to index 20
elseif index==20
    Num='0';
% Correlation below 0.2, so no digit will enter
else
    Num='';
end
end


