%% finish_maabada_Part2
% Oriel kowler 312496045
% Eliyahou garti 302169354

% plate_and_alpha 
% return The license plate and the angle of deviation

function [plate, alpha] = plate_and_alpha(pic)

% pic_ad = 'pic2/IMG_1.JPG';
% pic = imread(pic_ad);

% mask_n - retuen A mask of the black color in the picture, focus at the
% numbers color in the license plate.
mask_n = mask_num(pic);

% mask_y - retuen A mask of the yellow color in the picture, focus at the
% license plate color
mask_y = mask_yellow(pic);
% regionprops - returns measurements for the set of properties of the binary image
% 'BoundingBox'	- Position and size of the smallest box containing the region, returned as vector.
% 'Area' - Actual number of pixels in the region, returned as a scalar
% 'Image' - Image the same size as the bounding box of the region, returned as a binary (logical) array.
Iprops_n = regionprops(mask_n,'BoundingBox','Area', 'Image');  % Iprops_n - Regions of interest in the number mask in black
Iprops_y = regionprops(mask_y,'BoundingBox','Area', 'Image');  % Iprops_n - Areas of interest in the yellow color mask in the picture

% filtering the elements at mask_num by reference of 1<ref<4, when ref= height/width
count_n = numel(Iprops_n);            % returns the number of elements in array Iprops_n.
array_num=[];                         % array for the elements numbers after filtering
for i = 1:count_n
    x = Iprops_n(i).BoundingBox(3);   % width
    y = Iprops_n(i).BoundingBox(4);   % height
    ref = max(x,y)/min(x,y);          % ref = max(height,width)/min(height,width)
    if (ref>=1) & (ref<=4)            % if ref between 1 to 4 contain to the array_num
        array_num = [array_num; Iprops_n(i).BoundingBox];   
    end
end

% filtering the elements at mask_yellow by reference of 1<ref<5.5, when ref= height/width
count_y = numel(Iprops_y);            % returns the number of elements in array Iprops_y.
array_yel=[];                         % array for the elements yellow after filtering
for i = 1:count_y
    x = Iprops_y(i).BoundingBox(3);   % width
    y = Iprops_y(i).BoundingBox(4);   % height
    ref = max(x,y)/min(x,y);          % ref = max(height,width)/min(height,width)
    if (ref>=1) & (ref<=5.5)          % if ref between 1 to 5.5 contain to the array_yel
        array_yel = [array_yel; Iprops_y(i).BoundingBox];
    end
end


% check which num element match to yellow element
h_array_yel = height(array_yel);       % the numbers of elemnts in the array_yel
h_array_num = height(array_num);        % the numbers of elemnts in the array_num

array_max = [];                         % array for count the black elemnts in yellow boxes and
                                        % after we can found which yellow box contain the
                                        % maximum elements
                                        
count_inside = [];                      % An array designed to keep the characteristics of the black
                                        % parts for each yellow box
                                        
for i = 1:h_array_yel
    y_x = array_yel(i,1);               % X axis of yellow element
    y_y = array_yel(i,2);               % Y axis of yellow element
    y_w = array_yel(i,3);               % width of yellow element
    y_h = array_yel(i,4);               % height of yellow element
    count_max = 0;                      % reset the count
    count_inside = [count_inside; i i i i];     % create seperate in the table for each yellow box
    
    for j = 1:h_array_num
        n_x = array_num(j,1);       % X axis of number element
        n_y = array_num(j,2);       % Y axis of number element
        n_w = array_num(j,3);       % width of number element
        n_h = array_num(j,4);       % height of number element
        % check if the number element is in the yellow box
        if (n_x>=y_x) & ((n_x+n_w)<=(y_x+y_w)) & (n_y>=y_y) & ((n_y+n_h)<=(y_y+y_h)) 
            count_inside = [count_inside; array_num(j,:)];    % insert the characteristics of the black
                                                              % parts the yellow box array         
            count_max = count_max + 1;                        % add one to the yellow box counter
        end
    end
    array_max = [array_max count_max];                        % Inserts the sum of the black elements 
                                                              % found inside the yellow box
end

[M,I] = max(array_max(:));                % [Max_value, Index] - Extracts the maximum value
                                          % and its index from the array
                                          
inside_test = array_yel(I,:);             % Pulls out the appropriate yellow box according
                                          % to the index we received
                                          
plate = imcrop(pic, inside_test);         % crop the license plate from the original picture

% Finding the angle of deviation of the license plate according to the data of the numbers
index = find(count_inside==I);            % Retrieving the set of indexes of the yellow box
                                          % in order to access the data set of the numbers
% Extracting data from the information system in order to calculate the slope of the license plate
y2 = count_inside((index(1)+1),2);
y1 = count_inside((index(1)+M),2);
x1 = count_inside((index(1)+1),1);
x2 = count_inside((index(1)+M),1);
% License plate gradient
M_plate = (y2-y1)/(x2-x1);
% the deviation angle
alpha = atan(M_plate);          % found alpha in radian
alpha = (360*alpha) / (2*pi);   % convert from radian to degree
end
